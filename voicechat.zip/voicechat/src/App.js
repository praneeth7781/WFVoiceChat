import './App.css';
import Dictaphone from './components/Dictaphone';

function App() {
  return (
    <div className="App">
      <Dictaphone />
    </div>
  );
}

export default App;
